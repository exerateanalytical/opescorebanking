# SEC-LED-LAB-005: concurrency evidence (2026-11-05)
Classification: verified isolated synthetic lab; NOT a production posting/revocation engine.
CI PostgreSQL 16: https://github.com/exerateanalytical/opescorebanking/actions/runs/41943269917
CI conclusion success. Observed step output: SEC-LED-LAB-005 PASS: revocation/account-lock ordering and crash-before-commit rollback.
Tested separate SQL sessions: member FOR UPDATE lock blocks a concurrent REVOKED revision write until the posting transaction ends; account FOR SHARE lock blocks concurrent closure until that transaction ends. After COMMIT revocation advances to REVOKED revision 2. A deliberately terminated PostgreSQL backend during an active uncommitted posting rolls back that command, journal, lines, and outbox (no phantom commit).
Failure history retained: 41942964965 failed due to unsafe test harness that invoked pg_terminate_backend inside SQL WHERE (potentially affects unrelated sessions); fixed by explicit target-PID selection before termination. 41943127333 failed due to incorrect cumulative test-fixture row-count expectation; corrected and rerun as 41943269917.
No proof of: actual OIDC access-token validation, bank-to-bank service pool routing, network crash AFTER database commit but before API reply, connection failover RPO/RTO, distributed revocation, durable external settlement finality, real maker-checker, tamper-evident audit custody. All P0 production gates stay OPEN.
Official locking semantics: https://www.postgresql.org/docs/16/explicit-locking.html
NEXT EXACT TASK: SEC-TENANT-ROUTING-001 - implement bank-local OIDC token-to-membership-to-DB-principal service boundary; test crash-after-commit-before-response + outbox replay/UNKNOWN with bank failover.
