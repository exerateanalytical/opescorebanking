# LED-LAB-003 evidence and continuation (2026-11-05)
Classification: LABORATORY VERIFIED; NOT production-approved.
Parent baseline: 001 + 002, both reviewed and included for reproducibility.
New technical changes: xid8 creation-transaction fence for journal lines and outbox insert; immutable outbox evidence with one allowed delivery timestamp; deferred exactly-one journal per COMMITTED command.
GitHub CI run: https://github.com/exerateanalytical/opescorebanking/actions/runs/41940764696
CI tested PostgreSQL 16 with new disposable database. Final CI status SUCCESS. First attempt 41940617147 FAILED due to test fixture omitting mandatory posting_command.state; corrected in commit 23502cecd61924f85f99d441cf31f19cf9e53fca and rerun passed.
Tests: balanced journal creation, six adversarial rejection scenarios (late lines, late outbox, payload mutation, outbox deletion, orphan command, header-only journal), delivery timestamp transition, persisted row-count check.
Official database design references:
https://www.postgresql.org/docs/16/functions-info.html
https://www.postgresql.org/docs/16/transaction-id.html
Security verification framework: https://asvs.owasp.org/
P0 still OPEN: authenticated OIDC-to-bank-principal binding, membership/revocation lock ordering, same-transaction protected posting API, maker-checker, SoD, HSM custody, external crash/replay tests, reconciliation, outbox replay proof, privilege hardening and independent review.
Status: Tested isolated lab sub-checkpoint. 0 production-ready accepted work packages. No real money, external rails, regulatory certifications or banking licences.
NEXT EXACT TASK: SEC-TENANT-ROUTING-001: implement and PostgreSQL-integrate bank-local authenticated membership fence with idempotent protected atomic posting/outbox; prove concurrent revocation and crash UNKNOWN outcomes.
