# OPES Core Banking — WP-ACC-005 Checkpoint R

Execution date/time: 2026-10-20 18:00 WAT (Africa/Douala)
Programme: OPES Enterprise Banking Platform / OPES Core Banking
Phase: Phase 4 — Accounting Core / Financial Integrity
Active work package: WP-ACC-005 — PCEC Regulatory Accounting Extraction
Checkpoint: R
Production implementation: NOT READY

## Executive finding

Checkpoint R materially advances the legal interpretation of the COBAC R-2020/01 / D-2025/328 prudential exception without authorizing an executable calculation.

The official Republic of Congo Ministry of Finance indexed text for Decision COBAC D-2025/328 expressly:
- identifies COBAC R-2020/01 of 15 April 2020 as amending R-2010/02 on division of banking risks;
- quotes Article 7 as permitting COBAC, exceptionally, to reduce relevant risk quotités "au quart (25%)";
- states that the annual list is adopted by COBAC on reasoned proposals from the APECs;
- and, in Article 2 of the official PDF index, states that enterprises on the list benefit from a "réduction du quart" of the relevant quotités for one year.

The same decision therefore contains potentially different French formulations ("au quart" versus "réduction du quart"). Those formulations can imply different arithmetic results and must not be normalized by software engineering judgment alone.

A Republic of Congo government-hosted reproduction of R-2020/01 was also located. Its indexed text identifies:
- 25% as the maximum single-beneficiary exposure ratio from 1 January 2023;
- 10% as the large-exposure threshold from 1 January 2023;
- 800% as the aggregate large-exposure ceiling;
- the Article 7 exceptional regime;
- an institution-level condition that credit institutions benefiting from the exceptional quotités must have at least a satisfactory financial situation in COBAC's assessment;
- and entry into force from 1 June 2020.

The original signed bytes were not acquired and visual page inspection was blocked by the source hosts, so the reproduction is strong government-distributed evidence but is not promoted to issuer-byte-authenticated status.

## Key decisions

1. Instrument identity
R-2020/01 is now strongly corroborated as the COBAC amendment to R-2010/02 on division of risks. The conflicting description in the COBAC 2024 annual report is retained as a source-quality discrepancy rather than allowed to redefine the instrument.

2. Annual-list effect
D-2025/328 materially resolves that inclusion on the annual list creates the counterparty-side eligibility for the exceptional treatment for the relevant annual period.

3. Institution-level condition
The government-hosted R-2020/01 reproduction indicates that a credit institution applying the quotités must itself present at least a satisfactory financial situation in COBAC's assessment. Therefore annual listing is not modeled as unconditional automatic entitlement for every bank.

4. Arithmetic ambiguity
No executable coefficient is approved. "Au quart (25%)" and "réduction du quart" remain quarantined pending authoritative interpretation of whether the intended treatment is:
- reducing the relevant quotité to 25% of its ordinary value; or
- reducing the ordinary quotité by 25%.

5. Accounting boundary
Any prudential exception is a regulatory risk-calculation policy. It cannot mutate posted journals, customer balances, settlement records, or historical accounting entries.

6. R-2013/03
The reported R-2013/03 remains supported by secondary/legal research reproductions, including a complete two-page text, but no issuer-authenticated BEAC/COBAC original was obtained in this execution. It remains non-executable.

## Updated regulatory state

- GAP-ACC-038: R-2020/01 identity — materially resolved at instrument-subject level; signed issuer original still outstanding.
- GAP-ACC-039: COBAC 2024 annual-report description conflict — retained as source inconsistency; does not block instrument identity once stronger later supervisory/government evidence is applied.
- GAP-ACC-042: D-2025/328 webpage publication-date discrepancy — remains metadata-only uncertainty; decision text identifies a 12 Dec 2025 COBAC session.
- GAP-ACC-044: exceptional quotité linguistic/calculation ambiguity — OPEN P0 and strengthened by the official decision's mixed formulations.
- GAP-ACC-045: original-document acquisition blocker — OPEN.
- GAP-ACC-046: annual listing vs bank-specific entitlement — PARTIALLY RESOLVED. Counterparty listing effect is established; institution-level eligibility/approval semantics remain to be authenticated from issuer-grade R-2020/01 evidence.
- GAP-ACC-037 / GAP-ACC-040: R-2013/03 and same-day 2013 amendment reconciliation — OPEN.
- GAP-ACC-005: current CERBER/SPECTRA technical specification — OPEN P0.
- GAP-ENG-001: canonical durable engineering repository/environment — OPEN hard gate.

## New architecture decision

ADR-1087 — Dual-Gate Prudential Exception Eligibility and Non-Executable Ambiguity Quarantine

Status: PROPOSED

The exception engine must require both:
A. counterparty eligibility under an effective annual COBAC decision; and
B. institution eligibility under the applicable COBAC prudential condition.

A policy cannot transition to ACTIVE while calculation semantics are ambiguous or while required issuer-grade evidence is absent.

Suggested lifecycle:
DISCOVERED
→ SOURCE_CORROBORATED
→ ISSUER_AUTHENTICATED
→ LEGAL_INTERPRETATION_APPROVED
→ PRUDENTIAL_METHOD_APPROVED
→ INSTITUTION_ELIGIBILITY_CONFIRMED
→ TESTED
→ ACTIVATED
→ EXPIRED / REVOKED / SUPERSEDED

Any failure before ACTIVATED keeps the rule non-executable.

## Acceptance tests specified

- listed counterparty + eligible bank + unresolved coefficient => block activation
- listed counterparty + ineligible bank => exception denied
- unlisted counterparty + eligible bank => exception denied
- expired annual list => exception denied
- same counterparty appears in two annual decisions => select effective version only
- "au quart" interpretation candidate => no activation without approval
- "réduction du quart" interpretation candidate => no activation without approval
- source wording conflict => create regulatory conflict, not automatic normalization
- annual report conflicts with later primary decision => preserve both sources; stronger authority controls executable identity
- bank financial condition changes during year => reevaluate institution eligibility
- exceptional prudential calculation must not create or modify GL entries
- recalculation after policy correction preserves historical snapshots and prior evidence
- unknown regulatory effective date => no activation
- missing issuer-grade original => activation prohibited for P0 calculation semantics
- duplicate prudential policy activation request => idempotent
- rollback from ACTIVE after revocation => future calculations stop; historical results remain reconstructible

## Definition of Ready

Accounting Core / prudential exception subdomain remains NOT READY.

Blocking reasons include unresolved P0 calculation semantics, missing issuer-authenticated originals, incomplete consolidated PCEC, unresolved historical account ambiguities, missing current CERBER/SPECTRA specifications, no executable test harness, and no verified canonical engineering repository in this runtime.
