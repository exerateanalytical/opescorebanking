# Regulatory review — 2026-10-09
- CEMAC official 2009 Court Convention: https://cemac.int/wp-content/uploads/2025/01/Convention-Cour-de-Justice.pdf — primary historical text; current amendments and case-specific court orders unverified.
- June 2026 press account of CDEC/COBAC consultation: https://www.camerounlink.com/news/2026/6/18/cobac-la-cdec-conteste-un-projet-de-reglement-qualifiant-les-consignations-d-operations-de-banque-155783-grpe-1-seite-8/ — secondary, describes draft 2026 rules; NOT enacted text.
- June 2026 secondary account: https://orishas-finance.com/actualite/cemac-un-nouveau-differend-entre-la-cdec-et-la-cobac — secondary, describes CDEC correspondence; NOT issuer-authenticated.
- Official CEMAC texts catalogue https://cemac.int/textes/ — catalogue discovery only; not evidence of exhaustive legal corpus.
No complete authenticated 02/25 including printed p10 acquired. No certified court orders or authenticated original COBAC letters acquired. No negative inference from search absence.
