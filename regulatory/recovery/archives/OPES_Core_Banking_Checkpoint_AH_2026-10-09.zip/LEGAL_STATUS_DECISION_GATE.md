# Non-executable legal and financial gate
1. Verify document identity: issuer, instrument number, exact title, adoption/publication, full pagination, amendments, legal status.
2. Verify legal proceeding: registry certified case reference, operative court order, scope, service and effective dates. Mere filing or media report does not suspend a regulation.
3. Determine bank-specific obligations through qualified legal review and authorized governance approval.
4. Establish custody topology: same-bank CDEC liability reclassification versus external BEAC settlement; identify legal beneficiary, receipts, discharge and unresolved claims.
5. Require PCEC-approved posting templates, maker-checker, immutable double-entry, exact money, idempotency, external finality evidence, independent reconciliation.
6. Do not create payment instruction, customer closure, liability discharge, or final settlement status from unverified evidence.
7. Block execution when evidence incomplete, contested, expired, or inconsistent. Preserve raw records and escalation path.
