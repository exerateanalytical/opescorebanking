# Financial-integrity controls (proposed; no code)

- Maintain independent evidence gates for 01/25 (CDC supervision) and 02/25 (inactive accounts / dormant assets).
- A verified court filing is not a suspension order. A legal conclusion for one instrument does not automatically apply to another.
- Until the complete authenticated 02/25, institution profile, settlement topology and PCEC mapping are approved: prohibit auto-posting, liability reclassification, external payout and closure decisions derived from the disputed workflow.
- Allow evidence intake, human review, reconciliation investigation and immutable audit records without creating ledger effects.
- Do not treat absence from BEAC/CEMAC index as repeal, non-existence or inapplicability.
