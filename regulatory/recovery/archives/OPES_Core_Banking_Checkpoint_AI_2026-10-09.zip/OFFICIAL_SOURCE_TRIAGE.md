# Official-source triage (9 October 2026)

1. BEAC official COBAC regulation index: https://www.beac.int/supervision-bancaire/reglements-de-cobac/ — accessible index, but the page's listed instruments do not establish a complete or consolidated record for 02/25. **Negative search result is not legal evidence of absence.**
2. CEMAC official regulations and directives index: https://cemac.int/reglements-et-directives-2/ — index exists, but a current issuer-authenticated complete copy of dormant-account Regulation 02/25 was not located.
3. APECCAM reproduction of Regulation 01/25: https://apeccam.cm/wp-content/uploads/2025/07/Reglement-N%C2%B001_conditions-dexercice-et-supervision-activites-CD16072025085945.pdf — potentially useful corroboration; APECCAM hosting is not issuer certification and this is **01/25, not 02/25**.
4. July 20 2026 secondary litigation report: https://actucameroun.info/2026/07/20/cemac-la-cdec-conteste-la-supervision-de-la-cobac-et-rappelle-son-recours-devant-la-cour-de-justice/ — specifically discusses the challenge to 01/25; do not generalize its precise procedural assertion to 02/25 without certified court evidence.

## New precision safeguard
Distinguish regulation identifiers, subjects, litigated instruments, legal claims, judicial filings, and orders by unique primary-document identity. No cross-instrument status propagation from 01/25 to 02/25 without evidence.
