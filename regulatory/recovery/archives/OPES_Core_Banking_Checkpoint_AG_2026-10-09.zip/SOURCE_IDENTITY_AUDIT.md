# Primary-source identity audit — 9 October 2026
The BEAC website indexes a research Working Paper **BWP N°02/25**, entitled *Hétérogénéités et prévisions monétaires optimales dans la CEMAC*. This is NOT CEMAC Regulation N°02/25 on inactive accounts. Number-only search matches must be rejected as evidence.
Sources:
- https://www.beac.int/publications/working-papers/
- https://www.beac.int/wp-content/uploads/2016/10/CEMAC_MultiCountryQPM_vf05.pdf
Verification standard: issuer, document type, full identifier, title, signed/adopted date, publication, article completeness, amendments, authenticity, and effective applicability all separately checked.
Status: regulatory original and certified judicial records NOT OBTAINED. Prior claims are historical checkpoint statements, not authenticated by this search.
