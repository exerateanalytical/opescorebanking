# Checkpoint AG — evidence identity controls
Continuation of AF. No production implementation. This package nests AF unchanged. No new issuer-authenticated Regulation 02/25 or court-certified order acquired.
