# Evidence and legal execution gates
1. Intake: record URL, issuer, type, title, identifier, publication timestamp, retrieval timestamp, cryptographic digest, and custody.
2. Classify: working paper, communiqué, draft, secondary reproduction, original regulation, court filing, certified order, institution-specific correspondence. No cross-class promotion.
3. Authenticate: independently verify issuing body and complete pagination/annexes, amendment and consolidated status.
4. Legal review: record institutional license, jurisdiction, cohort, temporal applicability, judicial disposition, supersession, and unresolved conflicts.
5. CFO and Accounting Policy: separately approve liability and settlement topology, PCEC account mapping, independent reconciliation, correction and customer restitution.
6. Security approval: maker-checker, key custody, tamper-resistant audit, trusted source intake and immutable evidence snapshots.
7. Activation: dual authorization on effective-dated version; reject missing evidence or unresolved P0. No automatic activation from search results.
8. Incident: if a later order alters applicability, freeze affected unexecuted transfers, assess settled transfers, preserve journals and reconcile remediation via controlled adjustments only.
No financial transfer is authorized by this research.
