# OPES Core Banking — Checkpoint AL
Phase 4; WP-ACC-005 OPEN/BLOCKED. Inherits AK byte-for-byte. Research-only package; no code, no regulator correspondence transmitted, no banking tests executed.

Source finding: APECCAM hosts Regulation 01/25 PDF, a useful industry-hosted comparison source, not issuer certification. Republic of Congo Ministry of Finance maintains a regulations catalogue, but no complete authenticated 02/25 was acquired. Avoid confusing COBAC R-2025/02 (minimum capital) with CEMAC 02/25 (dormant assets).
