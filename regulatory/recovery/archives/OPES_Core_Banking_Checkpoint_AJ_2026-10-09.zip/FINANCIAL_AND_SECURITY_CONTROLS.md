# Financial execution gates
- No operational transition triggered by published quotations, correspondence summaries, court filing allegations or inferred effective dates.
- Regulatory eligibility decision, maker-checker approval, customer liability reclassification, external settlement and legal discharge are separate events.
- Model unknown network/settlement outcomes explicitly; never infer finality from a submitted request.
- Same-bank CDC credit and BEAC external settlement have potentially different ledger consequences; no account mapping is approved.
- For legal evidence: record source identity, original binary SHA-256, issuer validation method, version, notification/effective dates, applicability profile, reviewing counsel, approver, and supersession link. Use tamper-evident append-only evidence log, least privilege and dual approval.
- Preserve immutable journal and correction-by-reversal. Prevent duplicate posting using financial idempotency key and independent reconciliation.
- Cross-instrument court decisions must not be inherited from Regulation 01/25 to 02/25 or vice versa.
