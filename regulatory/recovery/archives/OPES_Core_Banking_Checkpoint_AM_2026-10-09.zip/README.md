# OPES Core Banking — Checkpoint AM
Continues AL without changing inherited archive bytes. This checkpoint is a focused evidence-quality update, not a completed regulatory acquisition.
The CEMAC 02/25 dormant-accounts instrument and COBAC R-2025/02 minimum-capital instrument are different.
No complete issuer-authenticated 02/25, certified court records or original COBAC-MINFI letter was obtained.
Production financial policy and code remain unauthorized.
