# Checkpoint AF official source verification
- BEAC payment systems overview: https://www.beac.int/systemes-paiement/presentation-generale/ distinguishes SYGMA, SYSTAC, GIMACPAY and participation models. This does not define institution-specific contractual access.
- BEAC Instruction 001/GR/2018: https://www.beac.int/wp-content/uploads/2016/10/Instruction_du_GR_001_GR_2018-1.pdf establishes card/wallet interoperability. Amendment status unverified.
- BEAC GIMAC page: https://www.beac.int/systemes-paiement/systeme-de-monetique-interbancaire/ identifies card/mobile/transfers ecosystem. Participant counts are dynamic, not design constants.
- BEAC Decision 013/GR/2022: https://www.beac.int/wp-content/uploads/2022/07/D%C3%A9cision-n%C2%B0013-GR-2022.pdf discusses a particular CAMPOST flow via GIMACPAY and SYGMA; NOT a universal settlement guarantee.
- CEMAC regulation 02/25 complete issuer-authenticated text and certified Court disposition NOT acquired. Existing P0s remain open.
