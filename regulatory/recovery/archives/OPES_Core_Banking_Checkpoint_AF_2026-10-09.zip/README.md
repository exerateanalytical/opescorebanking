Checkpoint AF: evidence-bounded review of payment infrastructure and unresolved WP-ACC-005. Contains prior AE archive unmodified. No regulator source PDF or court order acquired. No production code.
