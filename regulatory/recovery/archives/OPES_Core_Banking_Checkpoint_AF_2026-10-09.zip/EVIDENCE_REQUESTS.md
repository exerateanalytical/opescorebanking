# External evidence requests — not sent
1. COBAC/UMAC issuer: certified complete Regulation 02/25 including printed page 10, all annexes, corrections and amendments.
2. CEMAC Court registry: certified docket, interim orders, judgments and effective notifications concerning 01/25 and 02/25; confirm current procedural rules.
3. GIMAC/participant sponsor: participant profile, participation agreements, integration contract, sandbox, message schemas, security/HSM, reconciliation, fees, cutoffs, settlement and dispute manuals, certification checklist.
4. Bank finance/compliance: institution profile, legal interpretation, PCEC mappings, custody topology, independent reconciliation and approval signatures.
